import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  // Create Admin
  const admin = await prisma.admin.upsert({
    where: { username: 'admin' },
    update: {},
    create: {
      username: 'admin',
      password: 'admin123',
      name: 'Super Admin',
    },
  })
  console.log('✓ Created admin:', admin.username)

  // Create Students
  const students = [
    {
      username: 'student1',
      password: 'pass123',
      firstName: 'Kamal',
      lastName: 'Perera',
      address: '123 Main Street, Colombo',
      idNumber: 'ST001',
      whatsappNumber: '+94771234567',
      telegramNumber: 'kamal_perera',
      smsCallNumber: '+94771234567',
      district: 'Colombo',
      classType: 'KOREAN',
      batch: '2026',
    },
    {
      username: 'student2',
      password: 'pass123',
      firstName: 'Nimal',
      lastName: 'Fernando',
      address: '456 Temple Road, Kandy',
      idNumber: 'ST002',
      whatsappNumber: '+94782345678',
      telegramNumber: 'nimal_fernando',
      smsCallNumber: '+94782345678',
      district: 'Kandy',
      classType: 'ICT',
      batch: '2027',
    },
    {
      username: 'student3',
      password: 'pass123',
      firstName: 'Sunitha',
      lastName: 'Silva',
      address: '789 Beach Road, Galle',
      idNumber: 'ST003',
      whatsappNumber: '+94793456789',
      telegramNumber: 'sunitha_silva',
      smsCallNumber: '+94793456789',
      district: 'Galle',
      classType: 'MEDIA',
      batch: '2026',
    },
  ]

  for (const student of students) {
    await prisma.student.upsert({
      where: { username: student.username },
      update: {},
      create: student,
    })
    console.log('✓ Created student:', student.username)
  }

  // Create Staff
  const staff = [
    {
      name: 'Mr. Ranjith Bandara',
      position: 'Senior Lecturer',
      subject: 'KOREAN',
      email: 'ranjith@dmc.lk',
      phone: '+94711234567',
      description: '15+ years experience in Korean language teaching',
    },
    {
      name: 'Ms. Priya Nishantha',
      position: 'Lecturer',
      subject: 'ICT',
      email: 'priya@dmc.lk',
      phone: '+94722345678',
      description: 'ICT specialist with industry experience',
    },
    {
      name: 'Mr. Dinesh Jayasinghe',
      position: 'Media Coordinator',
      subject: 'MEDIA',
      email: 'dinesh@dmc.lk',
      phone: '+94733456789',
      description: 'Media studies expert and content creator',
    },
  ]

  for (const staffMember of staff) {
    await prisma.staff.upsert({
      where: { id: staffMember.id || 'temp-id' },
      update: {},
      create: staffMember,
    })
    console.log('✓ Created staff:', staffMember.name)
  }

  // Create Lessons for Korean class 2026 batch
  const classTypes = ['KOREAN', 'ICT', 'MEDIA']
  const batches = ['2026', '2027']

  for (const classType of classTypes) {
    for (const batch of batches) {
      for (let month = 1; month <= 12; month++) {
        await prisma.lesson.create({
          data: {
            title: `${classType} ${batch} - Month ${month}`,
            classType,
            batch,
            month: month.toString(),
            description: `Complete lessons for ${classType} ${batch} batch - Month ${month}`,
          },
        })
      }
    }
    console.log(`✓ Created lessons for ${classType}`)
  }

  console.log('✅ Seed completed successfully!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
