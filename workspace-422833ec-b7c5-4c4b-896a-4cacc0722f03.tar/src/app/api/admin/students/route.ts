import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const students = await db.student.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        payments: {
          take: 5,
          orderBy: { createdAt: 'desc' },
        },
      },
    })

    return NextResponse.json(students)
  } catch (error) {
    console.error('Error fetching students:', error)
    return NextResponse.json(
      { error: 'Failed to fetch students' },
      { status: 500 }
    )
  }
}
