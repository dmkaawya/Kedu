import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { username, password } = body

    // Find student by username
    const student = await db.student.findUnique({
      where: { username },
    })

    if (!student) {
      return NextResponse.json(
        { error: 'Invalid username or password' },
        { status: 401 }
      )
    }

    // Check password
    if (student.password !== password) {
      return NextResponse.json(
        { error: 'Invalid username or password' },
        { status: 401 }
      )
    }

    // Generate a simple token (in production, use JWT)
    const token = `${student.id}-${Date.now()}`

    return NextResponse.json({
      token,
      userId: student.id,
      student: {
        id: student.id,
        firstName: student.firstName,
        lastName: student.lastName,
        classType: student.classType,
        batch: student.batch,
      },
    })
  } catch (error) {
    console.error('Login error:', error)
    return NextResponse.json(
      { error: 'Login failed' },
      { status: 500 }
    )
  }
}
