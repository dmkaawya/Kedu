import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      firstName,
      lastName,
      address,
      idNumber,
      whatsappNumber,
      telegramNumber,
      smsCallNumber,
      district,
      classType,
      username,
      password,
      batch,
    } = body

    // Check if username already exists
    const existingStudent = await db.student.findUnique({
      where: { username },
    })

    if (existingStudent) {
      return NextResponse.json(
        { error: 'Username already exists' },
        { status: 400 }
      )
    }

    // Check if ID number already exists
    const existingId = await db.student.findUnique({
      where: { idNumber },
    })

    if (existingId) {
      return NextResponse.json(
        { error: 'ID number already registered' },
        { status: 400 }
      )
    }

    // Create new student
    const student = await db.student.create({
      data: {
        firstName,
        lastName,
        address,
        idNumber,
        whatsappNumber,
        telegramNumber: telegramNumber || null,
        smsCallNumber,
        district,
        classType,
        batch,
        username,
        password,
      },
    })

    return NextResponse.json({
      message: 'Registration successful',
      student: {
        id: student.id,
        firstName: student.firstName,
        lastName: student.lastName,
        username: student.username,
      },
    })
  } catch (error) {
    console.error('Registration error:', error)
    return NextResponse.json(
      { error: 'Registration failed' },
      { status: 500 }
    )
  }
}
