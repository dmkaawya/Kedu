import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const classType = searchParams.get('classType')
    const batch = searchParams.get('batch')

    const where: any = {}
    if (classType) where.classType = classType
    if (batch) where.batch = batch

    const lessons = await db.lesson.findMany({
      where,
      orderBy: [
        { classType: 'asc' },
        { batch: 'asc' },
        { month: 'asc' },
      ],
    })

    return NextResponse.json(lessons)
  } catch (error) {
    console.error('Error fetching lessons:', error)
    return NextResponse.json(
      { error: 'Failed to fetch lessons' },
      { status: 500 }
    )
  }
}
