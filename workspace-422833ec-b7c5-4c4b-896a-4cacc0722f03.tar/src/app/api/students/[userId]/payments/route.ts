import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: { userId: string } }
) {
  try {
    const payments = await db.payment.findMany({
      where: { studentId: params.userId },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json(payments)
  } catch (error) {
    console.error('Error fetching payments:', error)
    return NextResponse.json(
      { error: 'Failed to fetch payments' },
      { status: 500 }
    )
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { userId: string } }
) {
  try {
    const body = await request.json()
    const { paymentType, amount, transactionId, description } = body

    // Check if transaction ID already exists
    const existingPayment = await db.payment.findUnique({
      where: { transactionId },
    })

    if (existingPayment) {
      return NextResponse.json(
        { error: 'Transaction ID already exists' },
        { status: 400 }
      )
    }

    // Create payment
    const payment = await db.payment.create({
      data: {
        studentId: params.userId,
        paymentType,
        amount,
        transactionId,
        description,
      },
    })

    return NextResponse.json(payment)
  } catch (error) {
    console.error('Error creating payment:', error)
    return NextResponse.json(
      { error: 'Failed to create payment' },
      { status: 500 }
    )
  }
}
