import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "DMC Edu - Excellence in Education",
  description: "DMC Edu provides quality education in Korean, ICT, and Media studies. Join us for expert teaching and comprehensive learning resources.",
  keywords: ["DMC Edu", "Korean Class", "ICT Class", "Media Class", "Education Sri Lanka"],
  authors: [{ name: "DMC Edu Team" }],
  openGraph: {
    title: "DMC Edu",
    description: "Excellence in Education - Korean, ICT, Media Studies",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground min-h-screen`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
