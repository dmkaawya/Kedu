'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ThemeToggle } from '@/components/theme-toggle'
import {
  BookOpen,
  Users,
  Clock,
  GraduationCap,
  Globe,
  Languages,
  Smartphone,
  Mail,
  MapPin,
  ArrowRight,
  Star,
  CheckCircle2,
  BarChart3,
  Calendar,
} from 'lucide-react'

export default function Home() {
  const [activeSection, setActiveSection] = useState<'home' | 'about' | 'contact' | 'timetable' | 'portal'>('home')

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 w-full border-b border-border bg-background/80 backdrop-blur-md">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <GraduationCap className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 bg-clip-text text-transparent">
              DMC Edu
            </span>
          </div>

          <div className="hidden md:flex items-center gap-6">
            <button
              onClick={() => setActiveSection('home')}
              className={`text-sm font-medium transition-colors hover:text-primary ${activeSection === 'home' ? 'text-primary' : 'text-muted-foreground'}`}
            >
              Home
            </button>
            <button
              onClick={() => setActiveSection('about')}
              className={`text-sm font-medium transition-colors hover:text-primary ${activeSection === 'about' ? 'text-primary' : 'text-muted-foreground'}`}
            >
              About & Contact
            </button>
            <button
              onClick={() => setActiveSection('timetable')}
              className={`text-sm font-medium transition-colors hover:text-primary ${activeSection === 'timetable' ? 'text-primary' : 'text-muted-foreground'}`}
            >
              Timetable & Fees
            </button>
            <Link href="/portal">
              <Button className="bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 hover:opacity-90">
                <Users className="mr-2 h-4 w-4" />
                Student Portal
              </Button>
            </Link>
          </div>

          <div className="flex items-center gap-2">
            <ThemeToggle />
          </div>
        </div>
      </nav>

      {/* Mobile Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 border-t border-border bg-background/80 backdrop-blur-md">
        <div className="flex justify-around py-2">
          <button
            onClick={() => setActiveSection('home')}
            className={`flex flex-col items-center text-xs ${activeSection === 'home' ? 'text-primary' : 'text-muted-foreground'}`}
          >
            <BookOpen className="h-5 w-5 mb-1" />
            Home
          </button>
          <button
            onClick={() => setActiveSection('about')}
            className={`flex flex-col items-center text-xs ${activeSection === 'about' ? 'text-primary' : 'text-muted-foreground'}`}
          >
            <Mail className="h-5 w-5 mb-1" />
            About
          </button>
          <button
            onClick={() => setActiveSection('timetable')}
            className={`flex flex-col items-center text-xs ${activeSection === 'timetable' ? 'text-primary' : 'text-muted-foreground'}`}
          >
            <Calendar className="h-5 w-5 mb-1" />
            Timetable
          </button>
          <Link href="/portal" className="flex flex-col items-center text-xs text-muted-foreground">
            <Users className="h-5 w-5 mb-1" />
            Portal
          </Link>
        </div>
      </div>

      <main className="container py-8 md:py-12 pb-20 md:pb-12">
        {activeSection === 'home' && (
          <>
            {/* Hero Section */}
            <section className="mb-12 text-center">
              <div className="mb-6 flex justify-center">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 blur-3xl opacity-20 rounded-full"></div>
                  <GraduationCap className="relative h-24 w-24 text-primary" />
                </div>
              </div>
              <h1 className="mb-4 text-4xl font-bold tracking-tight sm:text-6xl">
                <span className="bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 bg-clip-text text-transparent">
                  Welcome to DMC Edu
                </span>
              </h1>
              <p className="mb-8 text-xl text-muted-foreground">
                Excellence in Korean, ICT, and Media Studies Education
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/portal">
                  <Button size="lg" className="bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 hover:opacity-90">
                    <GraduationCap className="mr-2 h-5 w-5" />
                    Join Our Classes
                  </Button>
                </Link>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => setActiveSection('timetable')}
                >
                  <Calendar className="mr-2 h-5 w-5" />
                  View Timetable
                </Button>
              </div>
            </section>

            {/* Features Section */}
            <section className="mb-12">
              <h2 className="mb-8 text-center text-3xl font-bold">Why Choose DMC Edu?</h2>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card className="border-2 border-pink-500/20 hover:border-pink-500/50 transition-all hover:shadow-lg hover:shadow-pink-500/20">
                  <CardHeader>
                    <div className="mb-2 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-pink-500 to-pink-600 text-white">
                      <Languages className="h-6 w-6" />
                    </div>
                    <CardTitle>Korean Language</CardTitle>
                    <CardDescription>
                      Master Korean with expert teachers and comprehensive curriculum
                    </CardDescription>
                  </CardHeader>
                </Card>

                <Card className="border-2 border-purple-500/20 hover:border-purple-500/50 transition-all hover:shadow-lg hover:shadow-purple-500/20">
                  <CardHeader>
                    <div className="mb-2 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 text-white">
                      <Globe className="h-6 w-6" />
                    </div>
                    <CardTitle>ICT Education</CardTitle>
                    <CardDescription>
                      Learn cutting-edge technology and ICT skills for the future
                    </CardDescription>
                  </CardHeader>
                </Card>

                <Card className="border-2 border-cyan-500/20 hover:border-cyan-500/50 transition-all hover:shadow-lg hover:shadow-cyan-500/20">
                  <CardHeader>
                    <div className="mb-2 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-500 to-cyan-600 text-white">
                      <Smartphone className="h-6 w-6" />
                    </div>
                    <CardTitle>Media Studies</CardTitle>
                    <CardDescription>
                      Explore media creation, content development, and digital storytelling
                    </CardDescription>
                  </CardHeader>
                </Card>
              </div>
            </section>

            {/* Programs Section */}
            <section className="mb-12">
              <h2 className="mb-8 text-center text-3xl font-bold">Our Programs</h2>
              <div className="grid gap-6">
                <Card className="overflow-hidden">
                  <div className="bg-gradient-to-r from-pink-500/10 to-pink-500/5 p-6">
                    <h3 className="text-2xl font-bold text-pink-500 mb-4">Korean Language Program</h3>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="h-5 w-5 text-pink-500 mt-0.5" />
                        <p className="text-muted-foreground">Comprehensive grammar and vocabulary</p>
                      </div>
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="h-5 w-5 text-pink-500 mt-0.5" />
                        <p className="text-muted-foreground">Speaking and listening practice</p>
                      </div>
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="h-5 w-5 text-pink-500 mt-0.5" />
                        <p className="text-muted-foreground">Reading and writing skills</p>
                      </div>
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="h-5 w-5 text-pink-500 mt-0.5" />
                        <p className="text-muted-foreground">Cultural immersion activities</p>
                      </div>
                    </div>
                  </div>
                </Card>

                <Card className="overflow-hidden">
                  <div className="bg-gradient-to-r from-purple-500/10 to-purple-500/5 p-6">
                    <h3 className="text-2xl font-bold text-purple-500 mb-4">ICT Program</h3>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="h-5 w-5 text-purple-500 mt-0.5" />
                        <p className="text-muted-foreground">Programming fundamentals</p>
                      </div>
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="h-5 w-5 text-purple-500 mt-0.5" />
                        <p className="text-muted-foreground">Web development</p>
                      </div>
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="h-5 w-5 text-purple-500 mt-0.5" />
                        <p className="text-muted-foreground">Database management</p>
                      </div>
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="h-5 w-5 text-purple-500 mt-0.5" />
                        <p className="text-muted-foreground">Industry standard tools</p>
                      </div>
                    </div>
                  </div>
                </Card>

                <Card className="overflow-hidden">
                  <div className="bg-gradient-to-r from-cyan-500/10 to-cyan-500/5 p-6">
                    <h3 className="text-2xl font-bold text-cyan-500 mb-4">Media Studies Program</h3>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="h-5 w-5 text-cyan-500 mt-0.5" />
                        <p className="text-muted-foreground">Video production</p>
                      </div>
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="h-5 w-5 text-cyan-500 mt-0.5" />
                        <p className="text-muted-foreground">Graphic design</p>
                      </div>
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="h-5 w-5 text-cyan-500 mt-0.5" />
                        <p className="text-muted-foreground">Digital marketing</p>
                      </div>
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="h-5 w-5 text-cyan-500 mt-0.5" />
                        <p className="text-muted-foreground">Content creation</p>
                      </div>
                    </div>
                  </div>
                </Card>
              </div>
            </section>

            {/* CTA Section */}
            <section className="mb-8">
              <Card className="border-2 bg-gradient-to-br from-pink-500/10 via-purple-500/10 to-cyan-500/10">
                <CardHeader className="text-center">
                  <CardTitle className="text-3xl">Ready to Start Your Journey?</CardTitle>
                  <CardDescription className="text-lg">
                    Join DMC Edu today and unlock your potential
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <Link href="/portal">
                    <Button size="lg" className="bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 hover:opacity-90">
                      <GraduationCap className="mr-2 h-5 w-5" />
                      Register Now
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </section>
          </>
        )}

        {activeSection === 'about' && (
          <div className="max-w-4xl mx-auto">
            <h1 className="mb-8 text-4xl font-bold text-center">About DMC Edu</h1>

            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Our Mission</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  DMC Edu is dedicated to providing high-quality education in Korean language, ICT, and Media Studies.
                  Our mission is to empower students with the skills and knowledge they need to succeed in today's
                  competitive world. We believe in practical, hands-on learning combined with theoretical foundations.
                </p>
              </CardContent>
            </Card>

            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Our Vision</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  To be the leading educational institution in Sri Lanka, known for excellence in language and technology
                  education. We aim to prepare students not just for exams, but for successful careers in their chosen fields.
                </p>
              </CardContent>
            </Card>

            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Why Choose Us?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3">
                  <Star className="h-5 w-5 text-yellow-500 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Experienced Faculty</h4>
                    <p className="text-muted-foreground">Our teachers are industry experts with years of teaching experience.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Star className="h-5 w-5 text-yellow-500 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Modern Teaching Methods</h4>
                    <p className="text-muted-foreground">We use the latest techniques and technology to enhance learning.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Star className="h-5 w-5 text-yellow-500 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Comprehensive Materials</h4>
                    <p className="text-muted-foreground">Students receive tutes, lessons, and recordings for continuous learning.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Star className="h-5 w-5 text-yellow-500 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Affordable Fees</h4>
                    <p className="text-muted-foreground">Quality education at competitive prices with flexible payment options.</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-pink-500/20 bg-gradient-to-br from-pink-500/5 to-purple-500/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mail className="h-5 w-5" />
                  Contact Us
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 text-pink-500 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Location</h4>
                    <p className="text-muted-foreground">Colombo, Sri Lanka</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Smartphone className="h-5 w-5 text-purple-500 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Phone</h4>
                    <p className="text-muted-foreground">+94 71 234 5678</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Mail className="h-5 w-5 text-cyan-500 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Email</h4>
                    <p className="text-muted-foreground">info@dmc-edu.lk</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeSection === 'timetable' && (
          <div className="max-w-6xl mx-auto">
            <h1 className="mb-8 text-4xl font-bold text-center">Class Timetable & Fees</h1>

            {/* Korean Class */}
            <Card className="mb-8 border-2 border-pink-500/20">
              <CardHeader className="bg-gradient-to-r from-pink-500/10 to-pink-500/5">
                <CardTitle className="text-2xl text-pink-500 flex items-center gap-2">
                  <Languages className="h-6 w-6" />
                  Korean Class
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                {/* 2026 Batch */}
                <div className="border-l-4 border-pink-500 pl-4">
                  <h3 className="text-xl font-bold mb-4">2026 Batch</h3>
                  <div className="grid gap-3 mb-4">
                    <div className="flex justify-between items-center p-3 bg-pink-500/10 rounded-lg">
                      <span className="font-medium">Theory</span>
                      <span className="text-pink-500 font-bold">Monday - 7:00 PM to 9:00 PM</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-pink-500/10 rounded-lg">
                      <span className="font-medium">Revision</span>
                      <span className="text-pink-500 font-bold">Wednesday - 8:00 AM to 2:00 AM</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-pink-500/10 rounded-lg">
                      <span className="font-medium">Paper Class</span>
                      <span className="text-pink-500 font-bold">Saturday - 5:00 PM to 8:00 PM</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-pink-500/10 rounded-lg">
                      <span className="font-medium">Extra Class</span>
                      <span className="text-pink-500 font-bold">Sunday - 2:00 PM to 4:00 PM</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Theory Fee:</span>
                      <span className="font-semibold">LKR 2,000/month</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Revision Fee:</span>
                      <span className="font-semibold">LKR 1,000/month</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Paper Class:</span>
                      <span className="font-semibold">LKR 500/month</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Extra Class:</span>
                      <span className="font-semibold text-green-500">FREE</span>
                    </div>
                  </div>
                </div>

                {/* 2027 Batch */}
                <div className="border-l-4 border-purple-500 pl-4">
                  <h3 className="text-xl font-bold mb-4">2027 Batch</h3>
                  <div className="grid gap-3 mb-4">
                    <div className="flex justify-between items-center p-3 bg-purple-500/10 rounded-lg">
                      <span className="font-medium">Theory</span>
                      <span className="text-purple-500 font-bold">Tuesday - 7:00 PM to 9:00 PM</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-purple-500/10 rounded-lg">
                      <span className="font-medium">Revision</span>
                      <span className="text-purple-500 font-bold">Thursday - 8:00 AM to 2:00 AM</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-purple-500/10 rounded-lg">
                      <span className="font-medium">Paper Class</span>
                      <span className="text-purple-500 font-bold">Saturday - 5:00 PM to 8:00 PM</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-purple-500/10 rounded-lg">
                      <span className="font-medium">Extra Class</span>
                      <span className="text-purple-500 font-bold">Sunday - 2:00 PM to 4:00 PM</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Theory Fee:</span>
                      <span className="font-semibold">LKR 2,000/month</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Revision Fee:</span>
                      <span className="font-semibold">LKR 1,000/month</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Paper Class:</span>
                      <span className="font-semibold text-green-500">FREE</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Extra Class:</span>
                      <span className="font-semibold">LKR 500/month</span>
                    </div>
                  </div>
                </div>

                {/* 2028 Batch */}
                <div className="border-l-4 border-gray-500 pl-4">
                  <h3 className="text-xl font-bold mb-4">2028 Batch</h3>
                  <p className="text-muted-foreground italic">Timetable pending...</p>
                </div>
              </CardContent>
            </Card>

            {/* ICT Class */}
            <Card className="mb-8 border-2 border-purple-500/20">
              <CardHeader className="bg-gradient-to-r from-purple-500/10 to-purple-500/5">
                <CardTitle className="text-2xl text-purple-500 flex items-center gap-2">
                  <Globe className="h-6 w-6" />
                  ICT Class
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                {/* 2026 Batch */}
                <div className="border-l-4 border-purple-500 pl-4">
                  <h3 className="text-xl font-bold mb-4">2026 Batch</h3>
                  <div className="grid gap-3 mb-4">
                    <div className="flex justify-between items-center p-3 bg-purple-500/10 rounded-lg">
                      <span className="font-medium">Theory</span>
                      <span className="text-purple-500 font-bold">Monday - 7:00 PM to 9:00 PM</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-purple-500/10 rounded-lg">
                      <span className="font-medium">Revision</span>
                      <span className="text-purple-500 font-bold">Wednesday - 8:00 AM to 2:00 AM</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-purple-500/10 rounded-lg">
                      <span className="font-medium">Paper Class</span>
                      <span className="text-purple-500 font-bold">Saturday - 5:00 PM to 8:00 PM</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-purple-500/10 rounded-lg">
                      <span className="font-medium">Extra Class</span>
                      <span className="text-purple-500 font-bold">Sunday - 2:00 PM to 4:00 PM</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Theory Fee:</span>
                      <span className="font-semibold">LKR 3,000/month</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Revision Fee:</span>
                      <span className="font-semibold">LKR 2,000/month</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Paper Class:</span>
                      <span className="font-semibold">LKR 2,000/month</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Extra Class:</span>
                      <span className="font-semibold text-green-500">FREE</span>
                    </div>
                  </div>
                </div>

                {/* 2027 Batch */}
                <div className="border-l-4 border-cyan-500 pl-4">
                  <h3 className="text-xl font-bold mb-4">2027 Batch</h3>
                  <div className="grid gap-3 mb-4">
                    <div className="flex justify-between items-center p-3 bg-cyan-500/10 rounded-lg">
                      <span className="font-medium">Theory</span>
                      <span className="text-cyan-500 font-bold">Tuesday - 7:00 PM to 9:00 PM</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-cyan-500/10 rounded-lg">
                      <span className="font-medium">Revision</span>
                      <span className="text-cyan-500 font-bold">Thursday - 8:00 AM to 2:00 AM</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-cyan-500/10 rounded-lg">
                      <span className="font-medium">Paper Class</span>
                      <span className="text-cyan-500 font-bold">Saturday - 5:00 PM to 8:00 PM</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-cyan-500/10 rounded-lg">
                      <span className="font-medium">Extra Class</span>
                      <span className="text-cyan-500 font-bold">Sunday - 2:00 PM to 4:00 PM</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Theory Fee:</span>
                      <span className="font-semibold">LKR 2,000/month</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Revision Fee:</span>
                      <span className="font-semibold">LKR 3,000/month</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Paper Class:</span>
                      <span className="font-semibold text-green-500">FREE</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Extra Class:</span>
                      <span className="font-semibold">LKR 500/month</span>
                    </div>
                  </div>
                </div>

                {/* 2028 Batch */}
                <div className="border-l-4 border-gray-500 pl-4">
                  <h3 className="text-xl font-bold mb-4">2028 Batch</h3>
                  <p className="text-muted-foreground italic">Timetable pending...</p>
                </div>
              </CardContent>
            </Card>

            {/* Media Class */}
            <Card className="mb-8 border-2 border-cyan-500/20">
              <CardHeader className="bg-gradient-to-r from-cyan-500/10 to-cyan-500/5">
                <CardTitle className="text-2xl text-cyan-500 flex items-center gap-2">
                  <Smartphone className="h-6 w-6" />
                  Media Class
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                {/* 2026 Batch */}
                <div className="border-l-4 border-cyan-500 pl-4">
                  <h3 className="text-xl font-bold mb-4">2026 Batch</h3>
                  <div className="grid gap-3 mb-4">
                    <div className="flex justify-between items-center p-3 bg-cyan-500/10 rounded-lg">
                      <span className="font-medium">Theory</span>
                      <span className="text-cyan-500 font-bold">Monday - 7:00 PM to 9:00 PM</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-cyan-500/10 rounded-lg">
                      <span className="font-medium">Revision</span>
                      <span className="text-cyan-500 font-bold">Wednesday - 8:00 AM to 2:00 AM</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-cyan-500/10 rounded-lg">
                      <span className="font-medium">Paper Class</span>
                      <span className="text-cyan-500 font-bold">Saturday - 5:00 PM to 8:00 PM</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-cyan-500/10 rounded-lg">
                      <span className="font-medium">Extra Class</span>
                      <span className="text-cyan-500 font-bold">Sunday - 2:00 PM to 4:00 PM</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Theory Fee:</span>
                      <span className="font-semibold">LKR 3,000/month</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Revision Fee:</span>
                      <span className="font-semibold">LKR 2,000/month</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Paper Class:</span>
                      <span className="font-semibold">LKR 1,000/month</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Extra Class:</span>
                      <span className="font-semibold text-green-500">FREE</span>
                    </div>
                  </div>
                </div>

                {/* 2027 Batch */}
                <div className="border-l-4 border-pink-500 pl-4">
                  <h3 className="text-xl font-bold mb-4">2027 Batch</h3>
                  <div className="grid gap-3 mb-4">
                    <div className="flex justify-between items-center p-3 bg-pink-500/10 rounded-lg">
                      <span className="font-medium">Theory</span>
                      <span className="text-pink-500 font-bold">Tuesday - 7:00 PM to 9:00 PM</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-pink-500/10 rounded-lg">
                      <span className="font-medium">Revision</span>
                      <span className="text-pink-500 font-bold">Thursday - 8:00 AM to 2:00 AM</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-pink-500/10 rounded-lg">
                      <span className="font-medium">Paper Class</span>
                      <span className="text-pink-500 font-bold">Saturday - 5:00 PM to 8:00 PM</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-pink-500/10 rounded-lg">
                      <span className="font-medium">Extra Class</span>
                      <span className="text-pink-500 font-bold">Sunday - 2:00 PM to 4:00 PM</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Theory Fee:</span>
                      <span className="font-semibold">LKR 3,000/month</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Revision Fee:</span>
                      <span className="font-semibold">LKR 2,000/month</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Paper Class:</span>
                      <span className="font-semibold text-green-500">FREE</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Extra Class:</span>
                      <span className="font-semibold">LKR 500/month</span>
                    </div>
                  </div>
                </div>

                {/* 2028 Batch */}
                <div className="border-l-4 border-gray-500 pl-4">
                  <h3 className="text-xl font-bold mb-4">2028 Batch</h3>
                  <p className="text-muted-foreground italic">Timetable pending...</p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-muted/50 mt-auto">
        <div className="container py-6 text-center text-sm text-muted-foreground">
          <p>© 2024 DMC Edu. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
