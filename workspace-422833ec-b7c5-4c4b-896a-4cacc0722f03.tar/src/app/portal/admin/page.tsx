'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { ThemeToggle } from '@/components/theme-toggle'
import {
  GraduationCap,
  LogOut,
  Users,
  BookOpen,
  CreditCard,
  DollarSign,
  ArrowLeft,
  Phone,
  MapPin,
  Mail,
  Calendar,
  Trash2,
  Eye,
} from 'lucide-react'

interface Student {
  id: string
  firstName: string
  lastName: string
  address: string
  idNumber: string
  whatsappNumber: string
  telegramNumber: string | null
  smsCallNumber: string
  district: string
  classType: string
  batch: string
  username: string
  createdAt: string
  payments?: Payment[]
}

interface Payment {
  id: string
  studentId: string
  paymentType: string
  amount: number
  transactionId: string
  description: string | null
  createdAt: string
  student?: Student
}

interface Lesson {
  id: string
  title: string
  classType: string
  batch: string
  month: string
  description: string | null
  videoUrl: string | null
  createdAt: string
}

interface Staff {
  id: string
  name: string
  position: string
  subject: string
  email: string | null
  phone: string | null
  description: string | null
}

export default function AdminDashboard() {
  const router = useRouter()
  const [students, setStudents] = useState<Student[]>([])
  const [payments, setPayments] = useState<Payment[]>([])
  const [lessons, setLessons] = useState<Lesson[]>([])
  const [staff, setStaff] = useState<Staff[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem('token')
    const userType = localStorage.getItem('userType')

    if (!token || userType !== 'admin') {
      router.push('/portal')
      return
    }

    fetchAdminData()
  }, [router])

  const fetchAdminData = async () => {
    try {
      // Fetch students
      const studentsRes = await fetch('/api/admin/students')
      if (studentsRes.ok) {
        const studentsData = await studentsRes.json()
        setStudents(studentsData)
      }

      // Fetch payments
      const paymentsRes = await fetch('/api/admin/payments')
      if (paymentsRes.ok) {
        const paymentsData = await paymentsRes.json()
        setPayments(paymentsData)
      }

      // Fetch lessons
      const lessonsRes = await fetch('/api/admin/lessons')
      if (lessonsRes.ok) {
        const lessonsData = await lessonsRes.json()
        setLessons(lessonsData)
      }

      // Fetch staff
      const staffRes = await fetch('/api/admin/staff')
      if (staffRes.ok) {
        const staffData = await staffRes.json()
        setStaff(staffData)
      }
    } catch (error) {
      console.error('Error fetching admin data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('userType')
    localStorage.removeItem('userId')
    router.push('/portal')
  }

  const calculateTotalRevenue = () => {
    return payments.reduce((sum, p) => sum + p.amount, 0)
  }

  const getStudentsByClass = (classType: string) => {
    return students.filter(s => s.classType === classType).length
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <GraduationCap className="h-16 w-16 animate-pulse mx-auto mb-4 text-primary" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b border-border bg-background/80 backdrop-blur-md sticky top-0 z-50">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <ArrowLeft className="h-5 w-5" />
            <span className="font-semibold">Back to Home</span>
          </Link>

          <div className="flex items-center gap-2">
            <GraduationCap className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 bg-clip-text text-transparent">
              DMC Edu Admin
            </span>
          </div>

          <div className="flex items-center gap-2">
            <Badge variant="destructive" className="hidden sm:flex">
              Admin Panel
            </Badge>
            <ThemeToggle />
            <Button variant="ghost" size="icon" onClick={handleLogout}>
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container flex-1 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
          <p className="text-muted-foreground">
            Manage students, payments, lessons, and staff
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <Card className="border-2 border-pink-500/20">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Students</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <Users className="h-6 w-6 text-pink-500" />
                <div className="text-2xl font-bold">{students.length}</div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 border-purple-500/20">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Payments</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <CreditCard className="h-6 w-6 text-purple-500" />
                <div className="text-2xl font-bold">{payments.length}</div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 border-cyan-500/20">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Revenue</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <DollarSign className="h-6 w-6 text-cyan-500" />
                <div className="text-2xl font-bold">LKR {calculateTotalRevenue().toLocaleString()}</div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 border-green-500/20">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Lessons</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <BookOpen className="h-6 w-6 text-green-500" />
                <div className="text-2xl font-bold">{lessons.length}</div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="students" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="students">Students</TabsTrigger>
            <TabsTrigger value="payments">Payments</TabsTrigger>
            <TabsTrigger value="lessons">Lessons</TabsTrigger>
            <TabsTrigger value="staff">Staff</TabsTrigger>
          </TabsList>

          {/* Students Tab */}
          <TabsContent value="students">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  All Students
                </CardTitle>
                <CardDescription>
                  Manage registered students
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="max-h-[600px]">
                  <div className="space-y-3">
                    {students.length === 0 ? (
                      <p className="text-center text-muted-foreground py-8">
                        No students registered yet
                      </p>
                    ) : (
                      students.map((student) => (
                        <Card key={student.id} className="border-2">
                          <CardContent className="p-4">
                            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-2">
                                  <h3 className="font-bold text-lg">
                                    {student.firstName} {student.lastName}
                                  </h3>
                                  <Badge>{student.classType}</Badge>
                                  <Badge variant="outline">{student.batch}</Badge>
                                </div>
                                <div className="grid gap-2 text-sm">
                                  <p className="text-muted-foreground">
                                    <span className="font-semibold">Username:</span> {student.username}
                                  </p>
                                  <p className="text-muted-foreground">
                                    <span className="font-semibold">ID:</span> {student.idNumber}
                                  </p>
                                  <p className="text-muted-foreground">
                                    <span className="font-semibold">District:</span> {student.district}
                                  </p>
                                  <div className="flex items-center gap-2 text-muted-foreground">
                                    <Phone className="h-3 w-3" />
                                    <span>WhatsApp: {student.whatsappNumber}</span>
                                  </div>
                                  {student.telegramNumber && (
                                    <div className="flex items-center gap-2 text-muted-foreground">
                                      <Mail className="h-3 w-3" />
                                      <span>Telegram: {student.telegramNumber}</span>
                                    </div>
                                  )}
                                  <div className="flex items-start gap-2 text-muted-foreground">
                                    <MapPin className="h-3 w-3 mt-1" />
                                    <span className="text-sm">{student.address}</span>
                                  </div>
                                </div>
                              </div>
                              <div className="flex gap-2">
                                <Button variant="outline" size="sm">
                                  <Eye className="h-4 w-4 mr-1" />
                                  View
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payments Tab */}
          <TabsContent value="payments">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  All Payments
                </CardTitle>
                <CardDescription>
                  Track all transactions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="max-h-[600px]">
                  <div className="space-y-3">
                    {payments.length === 0 ? (
                      <p className="text-center text-muted-foreground py-8">
                        No payments recorded yet
                      </p>
                    ) : (
                      payments.map((payment) => (
                        <Card key={payment.id} className="border-2">
                          <CardContent className="p-4">
                            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-2">
                                  <Badge>{payment.paymentType}</Badge>
                                  <span className="text-lg font-bold">LKR {payment.amount.toLocaleString()}</span>
                                </div>
                                <div className="grid gap-2 text-sm">
                                  <p className="text-muted-foreground">
                                    <span className="font-semibold">Transaction ID:</span> {payment.transactionId}
                                  </p>
                                  <p className="text-muted-foreground">
                                    <span className="font-semibold">Date:</span> {new Date(payment.createdAt).toLocaleString()}
                                  </p>
                                  {payment.student && (
                                    <p className="text-muted-foreground">
                                      <span className="font-semibold">Student:</span> {payment.student.firstName} {payment.student.lastName}
                                    </p>
                                  )}
                                  {payment.description && (
                                    <p className="text-muted-foreground">
                                      <span className="font-semibold">Description:</span> {payment.description}
                                    </p>
                                  )}
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Lessons Tab */}
          <TabsContent value="lessons">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  All Lessons
                </CardTitle>
                <CardDescription>
                  Manage lesson recordings
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="max-h-[600px]">
                  <div className="space-y-3">
                    {lessons.length === 0 ? (
                      <p className="text-center text-muted-foreground py-8">
                        No lessons available yet
                      </p>
                    ) : (
                      lessons.map((lesson) => (
                        <Card key={lesson.id} className="border-2">
                          <CardContent className="p-4">
                            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-2">
                                  <Badge>{lesson.classType}</Badge>
                                  <Badge variant="outline">{lesson.batch}</Badge>
                                  <Badge variant="secondary">Month {lesson.month}</Badge>
                                </div>
                                <h3 className="font-bold text-lg mb-2">{lesson.title}</h3>
                                {lesson.description && (
                                  <p className="text-sm text-muted-foreground">{lesson.description}</p>
                                )}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Staff Tab */}
          <TabsContent value="staff">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Staff Members
                </CardTitle>
                <CardDescription>
                  Manage teaching staff
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="max-h-[600px]">
                  <div className="space-y-3">
                    {staff.length === 0 ? (
                      <p className="text-center text-muted-foreground py-8">
                        No staff members added yet
                      </p>
                    ) : (
                      staff.map((member) => (
                        <Card key={member.id} className="border-2">
                          <CardContent className="p-4">
                            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-2">
                                  <h3 className="font-bold text-lg">{member.name}</h3>
                                  <Badge>{member.position}</Badge>
                                  <Badge variant="outline">{member.subject}</Badge>
                                </div>
                                <div className="grid gap-2 text-sm">
                                  {member.email && (
                                    <p className="text-muted-foreground flex items-center gap-2">
                                      <Mail className="h-3 w-3" />
                                      {member.email}
                                    </p>
                                  )}
                                  {member.phone && (
                                    <p className="text-muted-foreground flex items-center gap-2">
                                      <Phone className="h-3 w-3" />
                                      {member.phone}
                                    </p>
                                  )}
                                  {member.description && (
                                    <p className="text-muted-foreground">{member.description}</p>
                                  )}
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-muted/50 mt-auto">
        <div className="container py-4 text-center text-sm text-muted-foreground">
          © 2024 DMC Edu. All rights reserved.
        </div>
      </footer>
    </div>
  )
}
