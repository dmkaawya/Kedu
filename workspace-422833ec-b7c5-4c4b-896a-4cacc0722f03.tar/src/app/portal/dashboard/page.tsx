'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { ScrollArea } from '@/components/ui/scroll-area'
import { ThemeToggle } from '@/components/theme-toggle'
import {
  GraduationCap,
  LogOut,
  Users,
  BookOpen,
  CreditCard,
  User,
  Lock,
  Calendar,
  Phone,
  MapPin,
  Mail,
  Wallet,
  ArrowLeft,
  CheckCircle2,
  Clock,
  Star,
  DollarSign,
} from 'lucide-react'

interface Student {
  id: string
  firstName: string
  lastName: string
  address: string
  idNumber: string
  whatsappNumber: string
  telegramNumber: string | null
  smsCallNumber: string
  district: string
  classType: string
  batch: string
  username: string
}

interface Payment {
  id: string
  paymentType: string
  amount: number
  transactionId: string
  description: string | null
  createdAt: string
}

interface Lesson {
  id: string
  title: string
  month: string
  description: string | null
  videoUrl: string | null
}

interface Staff {
  id: string
  name: string
  position: string
  subject: string
  email: string | null
  phone: string | null
  description: string | null
}

export default function StudentDashboard() {
  const router = useRouter()
  const [student, setStudent] = useState<Student | null>(null)
  const [payments, setPayments] = useState<Payment[]>([])
  const [lessons, setLessons] = useState<Lesson[]>([])
  const [staff, setStaff] = useState<Staff[]>([])
  const [loading, setLoading] = useState(true)
  const [paymentModalOpen, setPaymentModalOpen] = useState(false)
  const [paymentData, setPaymentData] = useState({
    paymentType: 'CLASS_MONTH',
    amount: 0,
    transactionId: '',
    description: '',
  })

  useEffect(() => {
    const token = localStorage.getItem('token')
    const userType = localStorage.getItem('userId')

    if (!token || !userType) {
      router.push('/portal')
      return
    }

    fetchStudentData()
  }, [router])

  const fetchStudentData = async () => {
    try {
      const userId = localStorage.getItem('userId')

      // Fetch student data
      const studentRes = await fetch(`/api/students/${userId}`)
      if (studentRes.ok) {
        const studentData = await studentRes.json()
        setStudent(studentData)
      }

      // Fetch payments
      const paymentsRes = await fetch(`/api/students/${userId}/payments`)
      if (paymentsRes.ok) {
        const paymentsData = await paymentsRes.json()
        setPayments(paymentsData)
      }

      // Fetch lessons
      const lessonsRes = await fetch(`/api/lessons`)
      if (lessonsRes.ok) {
        const lessonsData = await lessonsRes.json()
        setLessons(lessonsData)
      }

      // Fetch staff
      const staffRes = await fetch(`/api/staff`)
      if (staffRes.ok) {
        const staffData = await staffRes.json()
        setStaff(staffData)
      }
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('userType')
    localStorage.removeItem('userId')
    router.push('/portal')
  }

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const userId = localStorage.getItem('userId')
      const response = await fetch(`/api/students/${userId}/payments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(paymentData),
      })

      if (response.ok) {
        alert('Payment recorded successfully!')
        setPaymentModalOpen(false)
        setPaymentData({
          paymentType: 'CLASS_MONTH',
          amount: 0,
          transactionId: '',
          description: '',
        })
        fetchStudentData()
      } else {
        const data = await response.json()
        alert(data.error || 'Payment failed')
      }
    } catch (error) {
      alert('Network error. Please try again.')
    }
  }

  const calculateTotalPayment = () => {
    return payments.reduce((sum, p) => sum + p.amount, 0)
  }

  const getAccessibleMonths = () => {
    // Count class month payments to determine accessible months
    const classMonthPayments = payments.filter(p => p.paymentType === 'CLASS_MONTH').length
    return Math.min(classMonthPayments + 3, 12) // Default 3 months + paid months
  }

  const getClassFees = () => {
    if (!student) return {}

    const fees: Record<string, number> = {
      'KOREAN-2026': {
        theory: 2000,
        revision: 1000,
        paper: 500,
      },
      'KOREAN-2027': {
        theory: 2000,
        revision: 1000,
        paper: 0,
        extra: 500,
      },
      'ICT-2026': {
        theory: 3000,
        revision: 2000,
        paper: 2000,
      },
      'ICT-2027': {
        theory: 2000,
        revision: 3000,
        paper: 0,
        extra: 500,
      },
      'MEDIA-2026': {
        theory: 3000,
        revision: 2000,
        paper: 1000,
      },
      'MEDIA-2027': {
        theory: 3000,
        revision: 2000,
        paper: 0,
        extra: 500,
      },
    }

    return fees[`${student.classType}-${student.batch}`] || {}
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <GraduationCap className="h-16 w-16 animate-pulse mx-auto mb-4 text-primary" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  if (!student) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card>
          <CardHeader>
            <CardTitle>Session Expired</CardTitle>
            <CardDescription>Please login again</CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/portal">
              <Button>Go to Login</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  const fees = getClassFees()
  const accessibleMonths = getAccessibleMonths()

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b border-border bg-background/80 backdrop-blur-md sticky top-0 z-50">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <ArrowLeft className="h-5 w-5" />
            <span className="font-semibold">Back to Home</span>
          </Link>

          <div className="flex items-center gap-2">
            <GraduationCap className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 bg-clip-text text-transparent">
              DMC Edu
            </span>
          </div>

          <div className="flex items-center gap-2">
            <Badge variant="outline" className="hidden sm:flex">
              {student.firstName} {student.lastName}
            </Badge>
            <ThemeToggle />
            <Button variant="ghost" size="icon" onClick={handleLogout}>
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container flex-1 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-2">
            Welcome, {student.firstName}! 👋
          </h1>
          <p className="text-muted-foreground">
            {student.classType} Class - {student.batch} Batch
          </p>
        </div>

        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <Wallet className="h-4 w-4" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="lessons" className="flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              Lessons
            </TabsTrigger>
            <TabsTrigger value="payments" className="flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              Payments
            </TabsTrigger>
            <TabsTrigger value="profile" className="flex items-center gap-2">
              <User className="h-4 w-4" />
              Profile
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card className="border-2 border-pink-500/20">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Total Payments</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-6 w-6 text-pink-500" />
                    <div className="text-2xl font-bold">LKR {calculateTotalPayment().toLocaleString()}</div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-purple-500/20">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Paid Months</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-6 w-6 text-purple-500" />
                    <div className="text-2xl font-bold">
                      {payments.filter(p => p.paymentType === 'CLASS_MONTH').length}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-cyan-500/20">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Tutes Bought</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <BookOpen className="h-6 w-6 text-cyan-500" />
                    <div className="text-2xl font-bold">
                      {payments.filter(p => p.paymentType === 'TUTE').length}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-green-500/20">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Lessons Bought</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Star className="h-6 w-6 text-green-500" />
                    <div className="text-2xl font-bold">
                      {payments.filter(p => p.paymentType === 'LESSON').length}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Staff Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Our Teaching Staff
                </CardTitle>
                <CardDescription>
                  Meet our experienced educators dedicated to your success
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {staff.map((member) => (
                    <Card key={member.id} className="overflow-hidden">
                      <div className="bg-gradient-to-br from-pink-500/10 via-purple-500/10 to-cyan-500/10 p-6">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="h-12 w-12 rounded-full bg-gradient-to-br from-pink-500 via-purple-500 to-cyan-500 flex items-center justify-center text-white font-bold">
                            {member.name.charAt(0)}
                          </div>
                          <div>
                            <h3 className="font-bold">{member.name}</h3>
                            <Badge variant="outline">{member.position}</Badge>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          <span className="font-semibold">Subject:</span> {member.subject}
                        </p>
                        {member.description && (
                          <p className="text-sm text-muted-foreground mb-2">
                            {member.description}
                          </p>
                        )}
                        <div className="space-y-1 text-sm">
                          {member.email && (
                            <p className="flex items-center gap-2">
                              <Mail className="h-3 w-3" />
                              {member.email}
                            </p>
                          )}
                          {member.phone && (
                            <p className="flex items-center gap-2">
                              <Phone className="h-3 w-3" />
                              {member.phone}
                            </p>
                          )}
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Lessons Tab */}
          <TabsContent value="lessons">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  Lesson Recordings
                </CardTitle>
                <CardDescription>
                  Access your lesson recordings. You can view lessons for {accessibleMonths} months.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {lessons
                    .filter(lesson => lesson.classType === student.classType && lesson.batch === student.batch)
                    .map((lesson, index) => {
                      const monthNum = parseInt(lesson.month)
                      const hasAccess = monthNum <= accessibleMonths

                      return (
                        <Card
                          key={lesson.id}
                          className={`overflow-hidden ${hasAccess ? 'border-2 border-green-500/30' : 'border-2 border-border'}`}
                        >
                          <div
                            className={`p-4 ${hasAccess ? 'bg-gradient-to-br from-green-500/10 to-green-500/5' : 'bg-muted/50'}`}
                          >
                            <div className="flex items-start justify-between mb-2">
                              <Badge className={hasAccess ? 'bg-green-500' : ''}>
                                Month {lesson.month}
                              </Badge>
                              {hasAccess && <CheckCircle2 className="h-5 w-5 text-green-500" />}
                            </div>
                            <h3 className="font-bold mb-2">{lesson.title}</h3>
                            {lesson.description && (
                              <p className="text-sm text-muted-foreground">{lesson.description}</p>
                            )}
                            {!hasAccess && (
                              <p className="text-sm text-muted-foreground mt-2 flex items-center gap-1">
                                <Lock className="h-3 w-3" />
                                This month is locked. Make a payment to unlock.
                              </p>
                            )}
                            {hasAccess && (
                              <Button className="mt-3 w-full bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500">
                                <BookOpen className="h-4 w-4 mr-2" />
                                Watch Now
                              </Button>
                            )}
                          </div>
                        </Card>
                      )
                    })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payments Tab */}
          <TabsContent value="payments" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  Make a Payment
                </CardTitle>
                <CardDescription>
                  Pay for class month, tutes, or lessons
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handlePayment} className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Payment Type</label>
                      <select
                        className="w-full px-3 py-2 rounded-md border border-input bg-background"
                        value={paymentData.paymentType}
                        onChange={(e) => setPaymentData({ ...paymentData, paymentType: e.target.value })}
                      >
                        <option value="CLASS_MONTH">Class Month</option>
                        <option value="TUTE">Buy Tute</option>
                        <option value="LESSON">Buy Lesson</option>
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Amount (LKR)</label>
                      <input
                        type="number"
                        className="w-full px-3 py-2 rounded-md border border-input bg-background"
                        placeholder="Enter amount"
                        value={paymentData.amount || ''}
                        onChange={(e) => setPaymentData({ ...paymentData, amount: parseFloat(e.target.value) || 0 })}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Transaction ID</label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 rounded-md border border-input bg-background"
                      placeholder="Enter transaction ID from bank payment"
                      value={paymentData.transactionId}
                      onChange={(e) => setPaymentData({ ...paymentData, transactionId: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Description (Optional)</label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 rounded-md border border-input bg-background"
                      placeholder="Payment description"
                      value={paymentData.description}
                      onChange={(e) => setPaymentData({ ...paymentData, description: e.target.value })}
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500"
                  >
                    <CreditCard className="h-4 w-4 mr-2" />
                    Record Payment
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Payment History */}
            <Card>
              <CardHeader>
                <CardTitle>Payment History</CardTitle>
                <CardDescription>
                  Track all your transactions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="max-h-96">
                  <div className="space-y-3">
                    {payments.length === 0 ? (
                      <p className="text-center text-muted-foreground py-8">
                        No payments recorded yet
                      </p>
                    ) : (
                      payments.map((payment) => (
                        <div key={payment.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <Badge variant="outline">{payment.paymentType}</Badge>
                              <span className="text-sm font-semibold">LKR {payment.amount.toLocaleString()}</span>
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {new Date(payment.createdAt).toLocaleString()}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              Transaction ID: {payment.transactionId}
                            </p>
                            {payment.description && (
                              <p className="text-sm text-muted-foreground">{payment.description}</p>
                            )}
                          </div>
                          <CheckCircle2 className="h-5 w-5 text-green-500" />
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  My Profile
                </CardTitle>
                <CardDescription>
                  View your registration details
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Personal Information */}
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-muted-foreground">Full Name</label>
                      <p className="text-lg font-semibold">
                        {student.firstName} {student.lastName}
                      </p>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-muted-foreground">Username</label>
                      <p className="text-lg font-semibold">{student.username}</p>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-muted-foreground">ID Number</label>
                      <p className="text-lg font-semibold">{student.idNumber}</p>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-muted-foreground">Class Type</label>
                      <Badge className="text-sm py-1 px-3">{student.classType}</Badge>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-muted-foreground">Batch</label>
                      <Badge variant="outline" className="text-sm py-1 px-3">{student.batch}</Badge>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-muted-foreground">District</label>
                      <p className="text-lg font-semibold">{student.district}</p>
                    </div>
                  </div>

                  {/* Contact Information */}
                  <div className="border-t border-border pt-6">
                    <h3 className="text-lg font-bold mb-4">Contact Information</h3>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                          <Phone className="h-4 w-4" />
                          WhatsApp Number
                        </label>
                        <p className="text-lg font-semibold">{student.whatsappNumber}</p>
                      </div>

                      {student.telegramNumber && (
                        <div className="space-y-2">
                          <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                            <Mail className="h-4 w-4" />
                            Telegram
                          </label>
                          <p className="text-lg font-semibold">{student.telegramNumber}</p>
                        </div>
                      )}

                      <div className="space-y-2">
                        <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                          <Phone className="h-4 w-4" />
                          SMS/Call Number
                        </label>
                        <p className="text-lg font-semibold">{student.smsCallNumber}</p>
                      </div>
                    </div>
                  </div>

                  {/* Address */}
                  <div className="border-t border-border pt-6">
                    <h3 className="text-lg font-bold mb-4">Address</h3>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        Full Address
                      </label>
                      <p className="text-lg">{student.address}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-muted/50 mt-auto">
        <div className="container py-4 text-center text-sm text-muted-foreground">
          © 2024 DMC Edu. All rights reserved.
        </div>
      </footer>
    </div>
  )
}
